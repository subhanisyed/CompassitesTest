package com.compassites.com.compassitestest;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends Activity {

    private TextView friendNameTv;
    private String type, title, content, imageUrl, locationUrl, moreImagesUrl;
    private NetworkImageView mNetworkImageView;
    private ImageLoader mImageLoader;
    private RecyclerView mRecyclerView;
    private MyRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        friendNameTv = (TextView) findViewById(R.id.my_friend_name);
        mImageLoader = CustomVolleyRequestQueue.getInstance(this.getApplicationContext())
                .getImageLoader();
        mNetworkImageView = (NetworkImageView) findViewById(R.id
                .networkImageView);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<FriendsStory> friendStory = new ArrayList<FriendsStory>();
        StringBuffer sb = new StringBuffer();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(getAssets().open(
                    "sample_response.json")));
            String temp;
            while ((temp = br.readLine()) != null)
                sb.append(temp);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                br.close(); // stop reading
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String myjsonstring = sb.toString();
        try {
            JSONObject jsonObjMain = new JSONObject(myjsonstring);

            String name = jsonObjMain.getString("name");
            if (name != null)
                friendNameTv.setText(name);
            String photoPath = jsonObjMain.getString("photo");

            mImageLoader.get(photoPath, ImageLoader.getImageListener(mNetworkImageView,
                    R.mipmap.ic_launcher, android.R.drawable
                            .ic_dialog_alert));
            mNetworkImageView.setImageUrl(photoPath, mImageLoader);

            String phoneNum = jsonObjMain.getString("phone");
            String email = jsonObjMain.getString("email");
            String contactUrl = jsonObjMain.getString("contact_url");

            JSONArray jsonArray = jsonObjMain.getJSONArray("our_story");

            for (int i = 0; i < jsonArray.length(); i++) {
                FriendsStory friendsStory = new FriendsStory();
                JSONObject jsonObj = jsonArray.getJSONObject(i);

                if (jsonObj.has("type")) {
                    type = jsonObj.getString("type");
                    friendsStory.setType(type);
                }
                if (jsonObj.has("title")) {
                    title = jsonObj.getString("title");
                    friendsStory.setTitle(title);
                }
                if (jsonObj.has("content")) {
                    content = jsonObj.getString("content");
                    friendsStory.setContent(content);
                }
                if (jsonObj.has("image_url")) {
                    imageUrl = jsonObj.getString("image_url");
                    friendsStory.setImageUrl(imageUrl);
                }
                if (jsonObj.has("location_url")) {
                    locationUrl = jsonObj.getString("location_url");
                    friendsStory.setLocationUrl(locationUrl);
                }
                if (jsonObj.has("more_images")) {
                    moreImagesUrl = jsonObj.getString("more_images");
                    friendsStory.setMoreImagesUrl(moreImagesUrl);
                }
                friendStory.add(friendsStory);
            }

            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            int width = size.x;

            adapter = new MyRecyclerAdapter(MainActivity.this, friendStory, width);
            mRecyclerView.setAdapter(adapter);
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}