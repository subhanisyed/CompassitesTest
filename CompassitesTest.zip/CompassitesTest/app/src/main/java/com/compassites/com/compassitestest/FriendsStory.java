package com.compassites.com.compassitestest;

/**
 * Created by M1027599 on 2/24/2016.
 */
public class FriendsStory {
    private String type;
    private String title;
    private String content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getLocationUrl() {
        return locationUrl;
    }

    public void setLocationUrl(String locationUrl) {
        this.locationUrl = locationUrl;
    }

    public String getMoreImagesUrl() {
        return moreImagesUrl;
    }

    public void setMoreImagesUrl(String moreImagesUrl) {
        this.moreImagesUrl = moreImagesUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    private String imageUrl;
    private String locationUrl;
    private String moreImagesUrl;
}
