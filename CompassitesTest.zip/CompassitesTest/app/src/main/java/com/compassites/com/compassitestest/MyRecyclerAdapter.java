package com.compassites.com.compassitestest;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;


import com.android.volley.toolbox.ImageLoader;

import java.util.List;

public class MyRecyclerAdapter extends RecyclerView.Adapter<FriendsListRowHolder> {
    private List<FriendsStory> friendsItemList;
    private Context mContext;
    private ImageLoader mImageLoader;
    private int width;

    public MyRecyclerAdapter(Context context, List<FriendsStory> friendsItemList, int width) {
        this.friendsItemList = friendsItemList;
        this.mContext = context;
        this.width = width;
    }

    @Override
    public FriendsListRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_item_layout, null);
        FriendsListRowHolder viewHolder = new FriendsListRowHolder(v);
        mImageLoader = CustomVolleyRequestQueue.getInstance(mContext)
                .getImageLoader();
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(FriendsListRowHolder friendsListRowHolder, int i) {
        FriendsStory friendItem = friendsItemList.get(i);
        if(friendItem.getType().equalsIgnoreCase("simple_card")){
            if (friendItem.getTitle() != null) {
                friendsListRowHolder.title.setVisibility(View.VISIBLE);
                friendsListRowHolder.title.setText(friendItem.getTitle());
            } else {
                friendsListRowHolder.title.setVisibility(View.GONE);
            }
            if (friendItem.getContent() != null) {
                friendsListRowHolder.content.setVisibility(View.VISIBLE);
                friendsListRowHolder.content.setText(friendItem.getContent());
            } else {
                friendsListRowHolder.content.setVisibility(View.GONE);
            }
            friendsListRowHolder.linearLayout.setBackgroundResource(R.drawable.border);
            friendsListRowHolder.imageView.setVisibility(View.GONE);
            friendsListRowHolder.webView.setVisibility(View.GONE);
            friendsListRowHolder.moreImagesTv.setVisibility(View.GONE);


        }else if(friendItem.getType().equalsIgnoreCase("checkin_card")){
            friendsListRowHolder.content.setVisibility(View.GONE);
            if (friendItem.getTitle() != null) {
                friendsListRowHolder.title.setVisibility(View.VISIBLE);
                friendsListRowHolder.title.setText(friendItem.getTitle());
            } else {
                friendsListRowHolder.title.setVisibility(View.GONE);
            }
            if (friendItem.getImageUrl() != null) {
                friendsListRowHolder.imageView.setLayoutParams(new LinearLayout.LayoutParams(width, 500));
                friendsListRowHolder.imageView.setVisibility(View.VISIBLE);
                friendsListRowHolder.imageView.setImageUrl(friendItem.getImageUrl(), mImageLoader);
            } else {
                friendsListRowHolder.imageView.setVisibility(View.GONE);
            }
            Log.d("LOGTAG", "URL: " + friendItem.getLocationUrl());
            if (friendItem.getLocationUrl() != null) {
                friendsListRowHolder.webView.setLayoutParams(new LinearLayout.LayoutParams(width, 1000));
                friendsListRowHolder.webView.setVisibility(View.VISIBLE);
                friendsListRowHolder.webView.setWebViewClient(new WebViewClient());
                friendsListRowHolder.webView.getSettings().setJavaScriptEnabled(true);
                friendsListRowHolder.webView.loadUrl(friendItem.getLocationUrl());
            } else {
                friendsListRowHolder.webView.setVisibility(View.GONE);
            }
            if (friendItem.getMoreImagesUrl() != null) {
                friendsListRowHolder.moreImagesTv.setVisibility(View.VISIBLE);
            } else {
                friendsListRowHolder.moreImagesTv.setVisibility(View.GONE);
            }
            friendsListRowHolder.linearLayout.setBackgroundResource(R.drawable.border);
        }

    }

    @Override
    public int getItemCount() {
        return (null != friendsItemList ? friendsItemList.size() : 0);
    }

}
