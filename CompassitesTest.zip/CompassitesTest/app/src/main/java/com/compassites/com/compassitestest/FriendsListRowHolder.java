package com.compassites.com.compassitestest;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.NetworkImageView;

public class FriendsListRowHolder extends RecyclerView.ViewHolder {

    protected TextView title,content;
    protected NetworkImageView imageView;
    protected WebView webView;
    protected LinearLayout linearLayout;
    protected TextView moreImagesTv;

    public FriendsListRowHolder(View view) {
        super(view);
        this.title = (TextView) view.findViewById(R.id.title);
        this.content = (TextView) view.findViewById(R.id.content);
        this.imageView = (NetworkImageView)view.findViewById(R.id.networkImageView);
        this.webView = (WebView)view.findViewById(R.id.locationWebView);
        this.linearLayout = (LinearLayout)view.findViewById(R.id.linearLayout);
        this.moreImagesTv = (TextView)view.findViewById(R.id.moreImagesTv);
    }

}